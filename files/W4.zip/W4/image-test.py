import cv2 as cv


img = cv.imread("harden.jpg", 1)
# print(img)
# print(type(img))
# print(img.shape)

 cv.imshow("harden.jpg", img)
 cv.waitKey(0)
 cv.destroyAllWindows()
